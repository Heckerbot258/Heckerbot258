<?php

$telegram_id = "7108210167";
$id_bot      = "6796064983:AAFFIUYWuEGEbvmFgdibhYgy5ElqhlzgDG4";
?>
